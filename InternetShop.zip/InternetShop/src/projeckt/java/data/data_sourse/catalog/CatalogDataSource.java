package projeckt.java.data.data_sourse.catalog;

import projeckt.java.data.models.Product;

import java.util.ArrayList;

public abstract class CatalogDataSource {
    public abstract ArrayList<Product> getCatalog();
}
